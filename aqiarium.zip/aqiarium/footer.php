</div>
<!-- / 全体wrapper -->

<!-- フッターエリア -->
<footer id="footer">


<!-- コピーライト表示 -->
<div id="copyright">
© <a href="<?php echo home_url(); ?>">© isao mitsuhashi. All Rights Reserved.</a>
</div>
<!-- /コピーライト表示 -->

</footer>
<!-- / フッターエリア -->

<?php wp_footer(); ?>


<!-- スマホ用ハンバーガーメニュー -->



<!-- ハンバーガーメニューbtn -->
<button id="btn" class="humbutton"><span></span></button>

<!-- ハンバーガーメニュー -->
<nav class="navigation">
	<ul class="nav-list">
		<li><a href="nav1">TOP</a></li>
		<li><a href="nav2">会社案内</a></li>
		<li><a href="nav3">サービス情報</a></li>
		<li><a href="nav4">資産管理メディア</a></li>
		<li><a href="nav5">Ys’お役立ち情報</a></li>
		<li><a href="nav6">お問い合わせ</a></li>
	</ul>
</nav>
		

		
		
 
<script>
 //ハンバーガーメニュー
$("#btn").on("click", function () {
	$("html").toggleClass("is_active");
});

// もともとメニュー横並びver
// ページを読み込んだ時とリサイズされた時に発動
$(window).on('load resize', function(){
	
	// ページの横幅取得
	var w = $(window).width();

	// 768px以下になったらハンバーガーメニュー閉じる処理
	if(w < 1024){
		$("html").removeClass("is_active");
	}

});
</script>
<!-- / ハンバーガーメニュー-->


<?php if ( is_home() || is_front_page() ) : ?>
</div>
<?php endif; ?>
</body>
</html>