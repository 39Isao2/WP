<?php get_header(); ?>

<!-- イメージヘッダー -->
<div class="head-img">
<?php echo get_the_post_thumbnail($post->ID, 'img-head'); ?>
</div>
<!-- / イメージヘッダー -->

<!-- 全体warapper -->
<div class="wrapper">

<!-- メインwrap -->
<div id="main">

	
	
<h2 class="pagetitle  mincho" style="margin-top: 100px;">404 Not Found
	
	
	
</h2>
	

<div class="page-contents">

<p class="has-text-align-center">お探しのページは見つかりませんでした。<br>
URLが間違っているか削除された可能性があります。<br>お手数ですが再度ご確認ください。</p>



<p class="has-text-align-center"><a href="https://ysc-inc.net/">TOPページへ</a></p>



<p style="padding-bottom:100px;"></p>



<p></p>



<p></p>



<p></p>



<p></p>



<p></p>



<p></p>



<p></p>



<p></p>



<p></p>



<p></p>
</div>


</div>
<!-- / メインwrap -->

<?php get_footer(); ?>