<!DOCTYPE html>
<html <?php language_attributes(); ?> style="margin-top:0px !important;">
<head>
<meta charset="<?php bloginfo( 'charset' ); ?>" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<link rel="stylesheet" href="<?php echo esc_url( get_template_directory_uri() );?>/responsive.css" type="text/css" media="screen, print" />
<link rel="stylesheet" href="<?php bloginfo('stylesheet_url'); ?>" type="text/css" media="screen, print" />
<?php if ( is_singular() ) wp_enqueue_script( 'comment-reply' ); ?>
<?php
wp_deregister_script('jquery');
wp_enqueue_script('jquery', '//ajax.googleapis.com/ajax/libs/jquery/1.7.1/jquery.min.js', array(), '1.7.1');
?>
<?php wp_head(); ?>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/3.7.2/animate.css">
</head>
<body <?php body_class(); ?> style="margin-top:0px;">
	
<?php if ( is_home() || is_front_page() ) : ?>
<div id="contents">
<?php endif; ?>

<!-- ヘッダー -->
<header id="header">

<!-- header-inner -->    
<div class="header-inner">
	<p class="disc">海のいきものたちに出会う旅 </p>
	
	<!-- ロゴ -->
	<h1 class="logo">
	<a href="<?php echo home_url(); ?>" title="<?php bloginfo('name'); ?>">Aqiarium</a>
	</h1>


	<!-- トップナビゲーション -->
	<nav id="nav" class="main-navigation" role="navigation">
	<?php wp_nav_menu( array( 'menu' => 'topnav', 'theme_location' => 'primary', 'menu_class' => 'nav-menu' ) ); ?>
	</nav>
	
</div>    
<!-- / header-inner-->
	
<!-- / ヘッダー -->

</header>