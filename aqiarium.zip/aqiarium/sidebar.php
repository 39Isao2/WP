<aside id="sidebar">
	<!-- カテゴリー -->
	<div id="recent-posts-3" class="widget widget_recent_entries">
	<div class="widget-title mincho news">カテゴリー</div>
	<ul>
	<?php
	  $terms = get_terms('news');
	  foreach ( $terms as $term ) {
		echo '<li class="cat-item cat-item-1">';
		echo '<a style="color: #45AAB8;" href="'.get_term_link($term).'">'.$term->name.'</a>';
		echo '</li>';
	  }
	?>
	</ul>
	</div>
</aside>