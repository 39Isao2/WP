<?php get_header(); ?>

<div class="main-image">
	<img class="bg_img" src="<?php echo get_template_directory_uri() .'/images/main_01.png' ?>" alt="メインイメージ" />
</div>

<!-- トップヘッダー画像 -->
<div class="top-header">
<img src="<?php echo (get_option('slideshow1')) ? get_option('slideshow1') : get_template_directory_uri() . '/images/main_01.jpg' ?>" alt="<?php bloginfo('name'); ?>" />
</div>
<!-- / トップヘッダー画像 -->


<!-- ウィジェットエリア（トップページヘッダー画像下（大）） -->
<div class="row">
	<div class="top-wide-contents">
		
	<h2> お知らせ</h2>
	<!-- news area-->
	<div class="top-wide-contents widget">
		<a href="http://aqua.local/category/news/" class="list_ico">一覧はこちら→</a> 
	<ul>
	<?php
	  $args = array(
		'posts_per_page' => 3 // 表示件数の指定
	  );
	  $posts = get_posts( $args );
	  foreach ( $posts as $post ): // ループの開始
	  setup_postdata( $post ); // 記事データの取得
	?>
	  <li>
		<a href="<?php the_permalink(); ?>"><?php the_time('Y/m/d'); ?>　<?php the_title(); ?></a>
	  </li>
	<?php
	  endforeach; // ループの終了
	  wp_reset_postdata(); // 直前のクエリを復元する
	?>
	</ul>
	</div>
	<!-- /news area-->
	
<div class="row">
<div class="top-wide-contents">
	<h2>オススメポイント</h2>

<!-- クラゲエリア -->
<section class="fl mt60 effect-fade">
	<div class="discription">
		<h3>神秘のクラゲエリア</h3>
		<p>神秘的なクラゲたちがあなたをお出迎えします。
			<a href="" class="btn">詳しくはこちら</a>
		</p>
	</div>
<div>
	<img class="buil_img" src="<?php echo get_template_directory_uri() . '/images/top1.jpg' ?>" alt="クラゲ画像">
</div>
</section>
<!-- /クラゲエリア -->
	
<!-- イルカのショー -->
<section class="fl mt100 effect-fade consal_block">
<div>
	<img class="buil_img"  src="<?php echo get_template_directory_uri() . '/images/top2.jpg' ?>"  alt="イルカのショー ">
</div>
<div class="discription">
	<h3>イルカのショー </h3>
	<p>
人気者、イルカのジョージと仲間たちが楽しいショーを繰り広げます。
		<a href="" class="btn">もっと見る</a>
	</p>
</div>
</section>
<!-- /イルカのショー  -->
	
	
<!-- 期間限定オリジナルカクテル -->
<section class="fl mt100 effect-fade">
<div class="discription">
	<h3>オリジナルカクテル</h3>
	<p>期間限定でオリジナルカクテルをプレゼントしています。
		<a href="https://ysc-inc.net/wait/" class="btn">もっと見る</a>
	</p>
</div>
<div>
	<img class="buil_img"  src="<?php echo get_template_directory_uri() . '/images/top3.jpg' ?>"  alt="オリジナルカクテル">
</div>
</section>
<!-- /オリジナルカクテル -->
</div>
</div>
</div>
</div>
	
	
	
	




<?php get_footer(); ?>