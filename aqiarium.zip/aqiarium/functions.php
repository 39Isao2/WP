<?php

/* ************************************************ 
*	コンテンツ幅
* ************************************************ */

if ( ! isset( $content_width ) ) {
	$content_width = 960;
}


/* ************************************************ 
*	ヘッダータグの消去
* ************************************************ */

remove_action('wp_head', 'adjacent_posts_rel_link_wp_head', 10, 0);
remove_action('wp_head', 'feed_links_extra',3,0);
remove_action('wp_head', 'rsd_link');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'index_rel_link');
remove_action('wp_head', 'parent_post_rel_link');
remove_action('wp_head', 'start_post_rel_link');
remove_action('wp_head', 'rel_canonical');


/* ************************************************ 
*	セルフピンバック禁止
* ************************************************ */

function no_self_ping( &$links ) {
$home = home_url();
foreach ( $links as $l => $link )
if ( 0 === strpos( $link, $home ) )
unset($links[$l]);
}
add_action( 'pre_ping', 'no_self_ping' );


/* ************************************************ 
*	タイトル表示
* ************************************************ */

add_theme_support( 'title-tag' );


/* ************************************************ 
*	カスタムメニュー
* ************************************************ */

register_nav_menus(array('primary' => 'グローバルメニュー'));


/* ************************************************ 
*	カスタム背景
* ************************************************ */

add_theme_support( 'custom-background' );


/* ************************************************ 
*	アイキャッチ画像
* ************************************************ */

add_theme_support( 'post-thumbnails' );
set_post_thumbnail_size( 768, 512, true );
add_image_size('img-head',2000,1000);


/* ************************************************ 
*	テキストウィジェットでショートコードを使用
* ************************************************ */

add_filter('widget_text', 'do_shortcode' );


/* ************************************************ 
*	カテゴリー説明文でHTMLタグを使用
* ************************************************ */

remove_filter('pre_term_description', 'wp_filter_kses');


/* ************************************************ 
*	ウィジェット
* ************************************************ */

add_action( 'widgets_init', 'minimal_wp_widgets_init' );
function minimal_wp_widgets_init() {
register_sidebar(array(
'name'=>'カテゴリーページ最下部',
'id'  => 'sidebar-1',
'description'   => 'PC表示時：横幅630px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'シングルページ記事下',
'id'  => 'sidebar-3',
'description'   => 'PC表示時：横幅630px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="single-widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'シングルページCTA',
'id'  => 'sidebar-4',
'description'   => 'PC表示時：横幅630px',
'before_widget' => '<div id="%1$s" class="widget %2$s cta-minimal">',
'after_widget' => '</div>',
'before_title' => '<div class="cta-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'シングルページ最下部',
'id'  => 'sidebar-5',
'description'   => 'PC表示時：横幅630px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="single-widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'フッター２列枠（左）',
'id'  => 'sidebar-6',
'description'   => 'PC表示時：横幅300px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="footer-widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'フッター２列枠（右）',
'id'  => 'sidebar-7',
'description'   => 'PC表示時：横幅300px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="footer-widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'トップページヘッダー画像下（大）',
'id'  => 'sidebar-8',
'description'   => 'PC表示時：横幅960px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="top-widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'トップページ２列枠（左）',
'id'  => 'sidebar-9',
'description'   => 'PC表示時：横幅465px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'トップページ２列枠（右）',
'id'  => 'sidebar-10',
'description'   => 'PC表示時：横幅465px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'トップページ下部（大）',
'id'  => 'sidebar-11',
'description'   => 'PC表示時：横幅960px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="widget-title mincho">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'トップページ下にニュース',
'id'  => 'sidebar-99',
'description'   => 'PC表示時：横幅960px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="widget-title mincho news">',
'after_title' => '</div>',
));
register_sidebar(array(
'name'=>'サイドバー',
'id'  => 'sidebar-100',
'description'   => 'PC表示時：横幅960px',
'before_widget' => '<div id="%1$s" class="widget %2$s">',
'after_widget' => '</div>',
'before_title' => '<div class="widget-title mincho news">',
'after_title' => '</div>',
));
}

/* ************************************************ 
*	フィードリンク
* ************************************************ */

add_theme_support( 'automatic-feed-links' );


/* ************************************************ 
*	エディタ拡張
* ************************************************ */

/*** テキストエディタにボタンを追加 ***/
function appthemes_add_quicktags() {
    if (wp_script_is('quicktags')){
?>
    <script type="text/javascript">
    QTags.addButton( 'youtube', 'YouTube', '<div class="youtube">', '</div>', '', 'YouTube tag', 201 );
    QTags.addButton( 'h1', 'H1', '<h1 class="blog-title">', '</h1>', '', 'h1 tag', 202 );
    QTags.addButton( 'h2', 'H2', '<h2>', '</h2>', '', 'h2 tag', 203 );
    QTags.addButton( 'h3', 'H3', '<h3>', '</h3>', '', 'h3 tag', 204 );
    QTags.addButton( 'h4', 'H4', '<h4>', '</h4>', '', 'h4 tag', 205 );
    QTags.addButton( 'button1', 'ボタン1', '<div class="bt-order"><a href="#">ボタン</a></div>', '', '', 'button1 tag', 206 );
    QTags.addButton( 'button2', 'ボタン2', '<div class="bt-order2"><a href="#">ボタン</a></div>', '', '', 'button2 tag', 207 );
    QTags.addButton( 'kakoi1', '囲みライン直線', '<div class="line-kakoi">テキスト</div>', '', '', 'kakoi1 tag', 208 );
    QTags.addButton( 'kakoi2', '囲みライン点線', '<div class="line-kakoi2">テキスト</div>', '', '', 'kakoi2 tag', 209 );
    </script>
<?php
    }
}
add_action( 'admin_print_footer_scripts', 'appthemes_add_quicktags' );


/*** ヴィジュアルエディタにボタンを追加 ***/
function ilc_mce_buttons($buttons){
array_push($buttons, "backcolor", "copy", "cut", "paste", "fontsizeselect", "cleanup");
return $buttons;
}
add_filter("mce_buttons", "ilc_mce_buttons");


/*** ビジュアルエディターにスタイルを適用する ***/
add_editor_style();




//カテゴリスラッグクラスをbodyクラスに含める
function add_category_slug_classes_to_body_classes($classes) {
  global $post;
  if ( is_single() ) {
    foreach((get_the_category($post->ID)) as $category)
       $classes[] = $category->category_nicename;
  }
  return $classes;
}
add_filter('body_class', 'add_category_slug_classes_to_body_classes');


// 固定ページのスラッグをbodyのクラスにつける
add_filter( 'body_class', 'add_page_slug_class_name' );
function add_page_slug_class_name( $classes ) {
  if ( is_page() ) {
    $page = get_post( get_the_ID() );
    $classes[] = $page->post_name;
  }
  return $classes;
}

// アイキャッチ画像を有効
add_theme_support('post-thumbnails');   // カスタム投稿タイプ example で thumbnail を使うので追記


?>