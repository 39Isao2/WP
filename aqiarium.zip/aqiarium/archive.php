<?php get_header(); ?>



<!-- 全体warapper -->
<div class="wrapper">

<!-- メインwrap -->
<div id="main">
	

	
	
<!-- コンテンツブロック -->
<div class="row">

<!-- 投稿記事 -->
<article>	

<!-- 投稿が存在するかを確認する条件文 -->
<?php if (have_posts()) : ?>
	
<div class="pagetitle mincho"><?php single_cat_title(); ?></div>
	
<?php endif; ?>
<!-- / カテゴリーの説明 -->


	
<!-- メインループ -->
<ul class="block-three">
	<?php if (have_posts()) : ?>
	<?php while (have_posts()) : the_post(); ?>
	<li>

		<!-- 投稿のリンク先 -->
		<a href="<?php the_permalink() ?>">
			
			<!-- サムネイルの表示 -->
			<?php the_post_thumbnail();?>
			
			<!-- 投稿日時 -->
			<span class="date">
				<?php the_time('Y年m月d日') ?>
			</span>
			
			<!-- 投稿タイトル -->
			<h2 class="blog_title">
			    <?php the_title(); ?>
			</h2>

		</a>

		<!-- 投稿内容の抜粋 -->
		<?php the_excerpt(); ?>
	</li>

	<?php endwhile; ?>
	<?php else : ?>
		<p>投稿が見つかりませんでした。</p>
	<?php endif; ?>
</ul>
<!-- /メインループ -->
	


<div class="clear"></div>
	
	
	
<!-- ページャー -->
<div class="pager">
<?php global $wp_rewrite;
$paginate_base = get_pagenum_link(1);
if(strpos($paginate_base, '?') || ! $wp_rewrite->using_permalinks()){
	$paginate_format = '';
	$paginate_base = add_query_arg('paged','%#%');
}
else{
	$paginate_format = (substr($paginate_base,-1,1) == '/' ? '' : '/') .
	user_trailingslashit('page/%#%/','paged');;
	$paginate_base .= '%_%';
}
echo paginate_links(array(
	'base' => $paginate_base,
	'format' => $paginate_format,
	'total' => $wp_query->max_num_pages,
	'mid_size' => 1,
	'current' => ($paged ? $paged : 1),
	'prev_text' => '«',
	'next_text' => '»',
)); ?>
</div>
<!-- / ページャー -->




</article>
<!-- / 投稿記事 -->

</div>
<!-- / コンテンツブロック -->


</div>
<!-- / メインwrap -->
<?php get_footer(); ?>