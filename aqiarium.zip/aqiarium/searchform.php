<div class="search">
<form method="get" id="searchform" action="<?php echo esc_url( home_url() ); ?>">
<fieldset>
<button type="submit"></button>
<input name="s" type="text" onfocus="if(this.value=='Search') this.value='';" onblur="if(this.value=='') this.value='Search';" value="Search" />
</fieldset>
</form>
</div>